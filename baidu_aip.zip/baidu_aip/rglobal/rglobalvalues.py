#-*-coding:utf-8 -*-
suirui_infos = {
    'shiyingle':{
    'name':u'石颍乐',
    'dep': u'会见通信云产品中心研发测试部',
    'pos': u'测试经理'
    },
    'fengwenlan':{
    'name':u'冯文澜',
    'dep': u'会见通信云产品中心',
    'pos': u'公司董事'
    },
    'liuqing':{
    'name':u'刘青',
    'dep': u'会见通信云产品中心研发测试部',
    'pos': u'测试工程师'
    },
    'bairenhe':{
    'name':u'白人赫',
    'dep': u'会见通信云产品中心产品部',
    'pos': u'产品经理'
    },'jiangsheng':{
    'name':u'蒋升',
    'dep': u'瞩目通信云产品中心',
    'pos': u'CPO'
    },'jinshaobo':{
    'name':u'晋少波',
    'dep': u'会见通信云产品中心产品部',
    'pos': u'产品经理'
    },'tianlijun':{
    'name':u'田丽君',
    'dep': u'销售运营中心销售支持部',
    'pos': u'产品经理'
    },'wangxiaoxu':{
    'name':u'王晓旭',
    'dep': u'会见通信云产品中心方案拓展部',
    'pos': u'部门经理'
    }
}
